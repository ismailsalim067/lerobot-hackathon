@echo off
setlocal
cd /d "%~dp0"
title Windows Camera Toolkit - Setup

:find_python
py -3.12 -c "import struct; assert struct.calcsize('P') == 8" >nul 2>&1
if not errorlevel 1 goto use_launcher
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" goto use_local
python -c "import sys,struct; assert sys.version_info[:2] == (3,12) and struct.calcsize('P') == 8" >nul 2>&1
if not errorlevel 1 goto use_path
if defined KIT_INSTALL_TRIED goto missing_python

echo Python 3.12 64-bit is required. It is separate from any existing Python version.
where winget >nul 2>&1
if errorlevel 1 goto missing_python
choice /C YN /M "Install Python 3.12 for your Windows account using winget?"
if errorlevel 2 goto missing_python
set KIT_INSTALL_TRIED=1
winget install --id Python.Python.3.12 --exact --source winget --scope user --interactive
if errorlevel 1 goto missing_python
goto find_python

:use_launcher
py -3.12 "%~dp0setup_env.py"
set KIT_EXIT=%ERRORLEVEL%
goto finished
:use_local
"%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "%~dp0setup_env.py"
set KIT_EXIT=%ERRORLEVEL%
goto finished
:use_path
python "%~dp0setup_env.py"
set KIT_EXIT=%ERRORLEVEL%
goto finished

:missing_python
echo.
echo Install 64-bit Python 3.12 from https://www.python.org/downloads/windows/
echo Then close this window and run 01_setup.cmd again.
echo If this is an ARM Windows laptop, use a compatible x64 Python installation.
pause
exit /b 1

:finished
echo.
if "%KIT_EXIT%"=="0" (echo Setup complete. Open 02_camera_tools.cmd next.) else (echo Setup failed. Read the message above and local\setup.log.)
pause
exit /b %KIT_EXIT%
