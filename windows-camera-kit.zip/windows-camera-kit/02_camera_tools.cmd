@echo off
setlocal
cd /d "%~dp0"
title Camera and Calibration File Toolkit
if not exist "%~dp0.venv\Scripts\python.exe" (
    echo Run 01_setup.cmd first.
    pause
    exit /b 1
)
"%~dp0.venv\Scripts\python.exe" "%~dp0kit.py" %*
set KIT_EXIT=%ERRORLEVEL%
if not "%KIT_EXIT%"=="0" pause
exit /b %KIT_EXIT%

