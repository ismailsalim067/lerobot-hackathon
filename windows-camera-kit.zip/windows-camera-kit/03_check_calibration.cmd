@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0.venv\Scripts\python.exe" (
    echo Run 01_setup.cmd first.
    pause
    exit /b 1
)
"%~dp0.venv\Scripts\python.exe" "%~dp0kit.py" calibration-menu
set KIT_EXIT=%ERRORLEVEL%
pause
exit /b %KIT_EXIT%

