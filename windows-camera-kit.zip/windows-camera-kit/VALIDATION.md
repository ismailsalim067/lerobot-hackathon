# Validation before delivery

Date: 2026-09-23.

## Completed

- 24 hardware-free unit tests passed on macOS ARM64 with Python 3.12.14,
  NumPy 2.2.6, OpenCV headless 4.13.0.92 and pyserial 3.5.
- All delivered Python files compiled successfully.
- Both existing SO-101 calibration files from the handoff session passed the
  offline schema and numeric-bounds checker. They are not included in this package.
- CLI help and calibration-check commands were exercised.
- PyPI dependency resolution and wheel downloads succeeded for the **actual pinned
  Windows x64 / Python 3.12 dependencies**:
  - `numpy-2.2.6-cp312-cp312-win_amd64.whl`
  - `opencv_python-4.12.0.88-cp37-abi3-win_amd64.whl`
  - `pyserial-3.5-py2.py3-none-any.whl`
- Reviewed the delivered sources: no motor SDK, serial-port opening, actuator
  calibration, torque-enable, teleoperation or motion execution is included.

## Not tested here

- Windows CMD execution, winget installation, and a complete native Windows setup.
- Windows camera privacy prompts, DirectShow/MSMF drivers, live preview windows,
  dual-camera USB bandwidth or camera hotplug behavior on the receiving laptop.
- Physical calibration correctness, hardware identity, robot motion or dataset recording.

The included Windows GitHub Actions workflow is ready to run when placed in a
repository's top-level `.github/workflows/`. It has **not** been run or reported as
passing from this workspace. It installs the pinned requirements and runs the
hardware-free checks on a Windows runner. It does not validate real cameras or robots.
