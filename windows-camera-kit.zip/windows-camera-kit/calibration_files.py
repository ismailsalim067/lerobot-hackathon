"""Offline SO-101 calibration JSON validation and immutable local backup."""

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

JOINTS = {"shoulder_pan": 1, "shoulder_lift": 2, "elbow_flex": 3,
          "wrist_flex": 4, "wrist_roll": 5, "gripper": 6}
FIELDS = ("id", "drive_mode", "homing_offset", "range_min", "range_max")


def validate(data):
    errors, warnings, summary = [], [], []
    if not isinstance(data, dict):
        return {"valid": False, "errors": ["Root must be a JSON object."], "warnings": [], "joints": []}
    for missing in sorted(set(JOINTS) - set(data)):
        errors.append(f"Missing joint: {missing}")
    for extra in sorted(set(data) - set(JOINTS)):
        errors.append(f"Unexpected joint: {extra}")
    for joint, expected_id in JOINTS.items():
        if joint not in data:
            continue
        row = data[joint]
        if not isinstance(row, dict):
            errors.append(f"{joint}: must be an object")
            continue
        bad = [key for key in FIELDS if type(row.get(key)) is not int]
        if bad:
            errors.append(f"{joint}: missing/non-integer fields: {', '.join(bad)}")
            continue
        if row["id"] != expected_id:
            errors.append(f"{joint}: expected motor ID {expected_id}")
        if row["drive_mode"] not in (0, 1):
            errors.append(f"{joint}: drive_mode must be 0 or 1")
        if not -2047 <= row["homing_offset"] <= 2047:
            errors.append(f"{joint}: homing_offset is outside the STS3215 signed 11-bit range")
        minimum, maximum = row["range_min"], row["range_max"]
        if not 0 <= minimum < maximum <= 4095:
            errors.append(f"{joint}: require 0 <= range_min < range_max <= 4095")
        span = maximum - minimum
        if 0 < span < 32:
            warnings.append(f"{joint}: very small recorded span; review the original calibration")
        if joint == "wrist_roll" and (minimum, maximum) != (0, 4095):
            warnings.append("wrist_roll: differs from the usual SO-101 full-turn calibration convention")
        summary.append({"joint": joint, "id": row["id"], "min": minimum, "max": maximum, "span": span})
    return {"valid": not errors, "errors": errors, "warnings": warnings, "joints": summary,
            "scope": "JSON structure and numeric bounds only; no physical calibration or hardware compatibility check."}


def inspect_file(path):
    path = Path(path)
    if path.stat().st_size > 1_000_000:
        raise ValueError("Expected a small calibration JSON file (maximum 1 MB).")
    raw = path.read_bytes()
    data = json.loads(raw.decode("utf-8-sig"))
    result = validate(data)
    result["source_name"] = path.name
    result["sha256"] = hashlib.sha256(raw).hexdigest()
    return result


def backup_file(path, role, destination):
    if role not in ("leader", "follower"):
        raise ValueError("Role must be leader or follower.")
    source = Path(path)
    result = inspect_file(source)
    if not result["valid"]:
        raise ValueError("Calibration file failed validation: " + "; ".join(result["errors"]))
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    folder = Path(destination) / role
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"{stamp}_{uuid4().hex[:8]}_{source.name}"
    raw = source.read_bytes()
    if hashlib.sha256(raw).hexdigest() != result["sha256"]:
        raise ValueError("Source changed while reading. Retry with a stable file.")
    with target.open("xb") as output:
        output.write(raw)
    result.update({"role": role, "backed_up_at": stamp, "applied_to_hardware": False})
    with target.with_suffix(".report.json").open("x", encoding="utf-8") as output:
        json.dump(result, output, indent=2)
    return target, result

