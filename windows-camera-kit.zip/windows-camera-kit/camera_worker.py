"""Camera-only child process. Does not import any robot or serial-control library."""

import argparse
import json
import sys
import time
from datetime import datetime
from pathlib import Path
from uuid import uuid4


def save_jpeg(cv2, frame, folder, index):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    name = f"camera_{index}_{datetime.now():%Y%m%d_%H%M%S_%f}_{uuid4().hex[:6]}.jpg"
    path = folder / name
    ok, encoded = cv2.imencode(".jpg", frame)
    if not ok:
        raise RuntimeError("JPEG encoding failed")
    # imwrite can fail on non-ASCII Windows paths; write the encoded bytes instead.
    with path.open("xb") as output:
        output.write(encoded.tobytes())
    return str(path)


def open_camera(cv2, index, backend, width, height, fps):
    api = {"dshow": cv2.CAP_DSHOW, "msmf": cv2.CAP_MSMF,
           "avfoundation": cv2.CAP_AVFOUNDATION, "auto": cv2.CAP_ANY}[backend]
    cap = cv2.VideoCapture(index, api)
    if cap.isOpened():
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        cap.set(cv2.CAP_PROP_FPS, fps)
    return cap


def probe(args, cv2):
    index = args.indices[0]
    result = {"index": index, "backend": args.backend, "opened": False, "frame_ok": False}
    cap = None
    try:
        cap = open_camera(cv2, index, args.backend, args.width, args.height, args.fps)
        result["opened"] = bool(cap.isOpened())
        if not result["opened"]:
            result["error"] = "Device could not be opened (absent, busy, or camera permission denied)."
            return result
        start, good, first_good, frame = time.monotonic(), 0, None, None
        while time.monotonic() - start < 5:
            ok, candidate = cap.read()
            if ok and candidate is not None and candidate.size:
                frame = candidate
                good += 1
                first_good = first_good if first_good is not None else time.monotonic()
                if good >= 5 and time.monotonic() - first_good >= 0.5:
                    break
            time.sleep(0.02)
        if frame is None:
            result["error"] = "Opened, but no valid video frame arrived."
            return result
        result.update({"frame_ok": True, "width": int(frame.shape[1]), "height": int(frame.shape[0]),
                       "reported_fps": float(cap.get(cv2.CAP_PROP_FPS)),
                       "actual_backend": cap.getBackendName()})
        if args.output:
            result["saved"] = save_jpeg(cv2, frame, args.output, index)
        return result
    except Exception as exc:
        result["error"] = str(exc)
        return result
    finally:
        if cap is not None:
            cap.release()


def preview(args, cv2):
    import numpy as np
    caps, last_frames, failures = {}, {}, {}
    title = "Camera preview - S: save all frames | Q / Esc: quit"
    try:
        for index in args.indices:
            cap = open_camera(cv2, index, args.backend, args.width, args.height, args.fps)
            caps[index] = cap
            if not cap.isOpened():
                raise RuntimeError(f"Camera {index} could not be opened. Close other camera apps or change backend.")
            failures[index] = 0
        cv2.namedWindow(title, cv2.WINDOW_NORMAL)
        last_time, shown_frames, display_fps = time.monotonic(), 0, 0.0
        while True:
            tiles = []
            for index, cap in caps.items():
                ok, frame = cap.read()
                if not ok or frame is None or not frame.size:
                    failures[index] += 1
                    if failures[index] >= 30:
                        raise RuntimeError(f"Camera {index} stopped returning frames.")
                    tile = np.zeros((480, 640, 3), dtype=np.uint8)
                    caption = f"Camera {index}: waiting for frames"
                else:
                    failures[index] = 0
                    last_frames[index] = frame.copy()
                    h, w = frame.shape[:2]
                    scale = min(640 / w, 480 / h)
                    small = cv2.resize(frame, (max(1, round(w * scale)), max(1, round(h * scale))))
                    tile = np.zeros((480, 640, 3), dtype=np.uint8)
                    y, x = (480 - small.shape[0]) // 2, (640 - small.shape[1]) // 2
                    tile[y:y + small.shape[0], x:x + small.shape[1]] = small
                    caption = f"Camera {index} | {w}x{h} | display {display_fps:.1f} fps"
                cv2.putText(tile, caption, (12, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                tiles.append(tile)
            if len(tiles) % 2 and len(tiles) > 1:
                tiles.append(np.zeros_like(tiles[0]))
            rows = [np.hstack(tiles[i:i + 2]) for i in range(0, len(tiles), 2)]
            cv2.imshow(title, np.vstack(rows))
            shown_frames += 1
            elapsed = time.monotonic() - last_time
            if elapsed >= 1:
                display_fps, shown_frames, last_time = shown_frames / elapsed, 0, time.monotonic()
            key = cv2.waitKey(1) & 0xFF
            if key in (ord('q'), ord('Q'), 27) or cv2.getWindowProperty(title, cv2.WND_PROP_VISIBLE) < 1:
                break
            if key in (ord('s'), ord('S')):
                for index, frame in last_frames.items():
                    if failures[index] == 0:
                        print("Saved:", save_jpeg(cv2, frame, args.output, index), flush=True)
    finally:
        for cap in caps.values():
            cap.release()
        cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("probe", "preview"))
    parser.add_argument("--indices", nargs="+", required=True, type=int)
    parser.add_argument("--backend", choices=("dshow", "msmf", "avfoundation", "auto"), required=True)
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--output", default="")
    args = parser.parse_args()
    if any(i < 0 or i > 31 for i in args.indices) or len(set(args.indices)) != len(args.indices):
        parser.error("Camera indices must be distinct integers from 0 to 31.")
    if args.mode == "preview" and (not args.output or len(args.indices) > 4):
        parser.error("Preview requires --output and at most four cameras.")
    import cv2
    if args.mode == "probe":
        result = probe(args, cv2)
        print(json.dumps(result), flush=True)
        return 0 if result["frame_ok"] else 1
    preview(args, cv2)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print(f"CAMERA ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
