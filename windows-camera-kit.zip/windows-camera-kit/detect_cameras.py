"""Compatibility entry point for the teammate's original detection script."""
import sys
from kit import main

if __name__ == "__main__":
    sys.exit(main(["detect", *sys.argv[1:]]))

