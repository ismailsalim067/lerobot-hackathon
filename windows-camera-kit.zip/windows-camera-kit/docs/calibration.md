# Calibration file handoff

This toolkit validates and backs up calibration JSON files **offline**. It does not
execute physical calibration or apply files to motors. A file passing these checks
does not establish that the robot is safe to move or that its joint directions are correct.

## Existing calibration from the Mac

If your team already has `my_leader.json` and `my_follower.json`, transfer those files
separately to the Windows operator. Keep track of which physical arm each file belongs
to, the date, and the LeRobot version used to produce it. The files are not bundled in
this public repository.

1. Run `03_check_calibration.cmd` on Windows.
2. Paste the path to one calibration JSON. Paths containing spaces are supported.
3. Review the six joint entries, numeric bounds and any warnings.
4. Enter `leader` or `follower` to create a local backup of the original bytes.
5. Repeat for the other file.

The original file is not changed. Backups have unique names and a SHA-256 digest.
They are stored below `local/calibration_backups/`, which is excluded from Git.
This operation does not place the file in an active LeRobot configuration.

## What validation establishes

- Expected SO-101 joint names and motor IDs 1 through 6 are present.
- Numeric fields have integer types, with no booleans accepted as integers.
- Encoder limits are ordered and within 0..4095.
- Homing offsets and drive-mode values are within the file format's expected bounds.
- Unusually small ranges and a nonstandard wrist-roll range are flagged for review.

It does not establish that the recorded range covers the full mechanical travel,
that the file belongs to the connected arm, that any motor is working, or that a
particular LeRobot version will interpret the physical setup correctly.

## Physical calibration

Physical calibration, joint-direction checks and first-motion acceptance must be
handled by the on-site operator using the manufacturer's verified procedure and
documentation for the installed software version. This repository does not include
an actuator-calibration launcher or a command that writes calibration to a robot.

References: [SO-101 documentation](https://huggingface.co/docs/lerobot/so101),
[LeRobot compatibility documentation](https://huggingface.co/docs/lerobot/backward_compatibility).

