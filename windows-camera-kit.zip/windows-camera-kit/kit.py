"""Windows camera diagnostics and offline calibration-file tools. No robot actuation."""

import argparse
import importlib.metadata
import json
import os
import platform
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from calibration_files import backup_file, inspect_file

ROOT = Path(__file__).resolve().parent
LOCAL = ROOT / "local"
DEFAULT_BACKEND = "dshow" if os.name == "nt" else "avfoundation" if sys.platform == "darwin" else "auto"
BACKENDS = ("dshow", "msmf", "avfoundation", "auto")


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + "." + uuid4().hex + ".tmp")
    try:
        temp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def settings():
    path = LOCAL / "cameras.json"
    if not path.exists():
        return {"backend": DEFAULT_BACKEND, "cameras": {}}
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("backend") not in BACKENDS or not isinstance(data.get("cameras"), dict):
        raise ValueError("Invalid local/cameras.json. Rename the file and detect cameras again.")
    return data


def selected_backend(value=None):
    return value or settings()["backend"]


def worker_command(mode, indices, backend, width=640, height=480, fps=30, output=None):
    if not indices or len(set(indices)) != len(indices) or any(type(i) is not int or i < 0 or i > 31 for i in indices):
        raise ValueError("Choose distinct camera indices from 0 to 31.")
    if backend not in BACKENDS:
        raise ValueError("Unknown video backend")
    command = [sys.executable, str(ROOT / "camera_worker.py"), mode, "--indices", *map(str, indices),
               "--backend", backend, "--width", str(width), "--height", str(height), "--fps", str(fps)]
    if output is not None:
        command.extend(["--output", str(output)])
    return command


def probe_camera(index, backend, width=640, height=480, fps=30, output=None, timeout=15):
    command = worker_command("probe", [index], backend, width, height, fps, output)
    try:
        process = subprocess.run(command, capture_output=True, text=True, encoding="utf-8",
                                 errors="replace", timeout=timeout, cwd=ROOT)
    except subprocess.TimeoutExpired:
        return {"index": index, "backend": backend, "opened": False, "frame_ok": False,
                "error": f"Camera driver did not finish within {timeout}s; child process was stopped."}
    for line in reversed(process.stdout.splitlines()):
        try:
            result = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(result, dict) and result.get("index") == index and "frame_ok" in result:
            return result
    return {"index": index, "backend": backend, "opened": False, "frame_ok": False,
            "error": process.stderr.strip()[-1200:] or "No camera result returned."}


def detect(backend, maximum=9):
    print(f"Checking camera indices 0..{maximum} with {backend}.")
    print("Detection briefly opens cameras to check frames. It does not save pictures.")
    results = []
    for index in range(maximum + 1):
        result = probe_camera(index, backend)
        results.append(result)
        if result["frame_ok"]:
            print(f"  {index}: WORKING  {result['width']}x{result['height']}  reported fps={result['reported_fps']:.1f}", flush=True)
        else:
            print(f"  {index}: unavailable - {result.get('error', 'no frame')}", flush=True)
    report = {"time": datetime.now(timezone.utc).isoformat(), "backend": backend, "results": results}
    write_json(LOCAL / "camera_detection.json", report)
    print("Saved local/camera_detection.json. Preview the picture to identify each camera.")
    print("A device index may change after reconnecting or switching backend.")
    return any(row["frame_ok"] for row in results)


def show_ports():
    from serial.tools import list_ports
    ports = []
    for p in sorted(list_ports.comports(), key=lambda p: p.device):
        item = {"port": p.device, "description": p.description, "manufacturer": p.manufacturer,
                "vid": p.vid, "pid": p.pid}
        ports.append(item)
        print(f"{p.device}: {p.description}")
    if not ports:
        print("No serial ports are currently listed by Windows.")
    print("This is an OS device list only. No serial port was opened or motor queried.")
    write_json(LOCAL / "serial_ports.json", ports)
    return ports


def doctor():
    result = {"time": datetime.now(timezone.utc).isoformat(), "os": platform.system(),
              "os_release": platform.release(), "architecture": platform.machine(),
              "python": platform.python_version(), "packages": {}}
    missing = []
    for name in ("numpy", "opencv-python", "pyserial"):
        try:
            result["packages"][name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result["packages"][name] = "not installed"
            missing.append(name)
    try:
        import cv2
        import numpy
        import serial.tools.list_ports
        result["opencv_import"] = cv2.__version__
    except ImportError as exc:
        result["import_error"] = str(exc)
        missing.append("dependency import")
    print(json.dumps(result, indent=2))
    write_json(LOCAL / "system_check.json", result)
    if missing:
        print("Run 01_setup.cmd. Missing/incompatible:", ", ".join(missing))
    print("System check did not open cameras or serial ports.")
    return not missing


def preview(indices, backend, width, height, fps):
    if len(indices) > 4:
        raise ValueError("Preview supports at most four cameras at once.")
    command = worker_command("preview", indices, backend, width, height, fps, LOCAL / "snapshots")
    print("Focus the preview window: S = save current frames; Q or Esc = close.")
    print("If a camera driver freezes, return to this terminal and press Ctrl+C.")
    process = subprocess.Popen(command, cwd=ROOT)
    try:
        return process.wait() == 0
    except KeyboardInterrupt:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        print("Preview stopped.")
        return True


def snapshots(indices, backend, width, height, fps):
    print("Taking one photo per selected camera, sequentially (not synchronized).")
    results = []
    for index in indices:
        result = probe_camera(index, backend, width, height, fps, LOCAL / "snapshots")
        results.append(result)
        print(result.get("saved", f"Camera {index}: {result.get('error', 'snapshot failed')}"))
    write_json(LOCAL / "last_snapshot_report.json", {"backend": backend, "results": results})
    return all(row.get("saved") for row in results)


def ask_indices():
    text = input("Camera index/indices to open (e.g. 1 or 1 2; blank cancels): ").strip()
    if not text:
        return []
    indices = [int(v) for v in text.replace(",", " ").split()]
    worker_command("probe", indices, DEFAULT_BACKEND)
    return indices


def label_cameras():
    config = settings()
    print("Preview and identify cameras first. Examples: scene, wrist.")
    label = input("Camera label (blank cancels): ").strip()
    if not label:
        return
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,31}", label):
        raise ValueError("Use a short label starting with a letter, then letters/digits/_/-.")
    indices = ask_indices()
    if len(indices) != 1:
        raise ValueError("Choose exactly one camera for this label.")
    index = indices[0]
    for other, item in config["cameras"].items():
        if other != label and item["index"] == index:
            raise ValueError(f"Index {index} is already labeled {other}. Edit local/cameras.json if needed.")
    config["cameras"][label] = {"index": index, "width": 640, "height": 480, "fps": 30,
                                  "identified_at": datetime.now(timezone.utc).isoformat()}
    write_json(LOCAL / "cameras.json", config)
    print("Saved local/cameras.json. These are local camera labels, not a robot-control configuration.")


def calibration_menu():
    print("OFFLINE CALIBRATION FILE CHECK / BACKUP")
    print("This checks an existing JSON file. It does not calibrate an arm or write parameters to motors.")
    text = input("Path to an existing LeRobot SO-101 calibration JSON (blank cancels): ").strip().strip('"')
    if not text:
        return True
    source = Path(text).expanduser()
    result = inspect_file(source)
    print(json.dumps(result, indent=2))
    if not result["valid"]:
        return False
    role = input("Backup role: leader / follower (blank skips backup): ").strip().lower()
    if not role:
        return True
    target, _ = backup_file(source, role, LOCAL / "calibration_backups")
    print("Local backup saved:", target)
    print("Nothing was applied to hardware. See docs/calibration.md for the handoff checklist.")
    return True


def export_report():
    report = {"time": datetime.now(timezone.utc).isoformat(), "scope": "Local diagnostics, no photographs or motor commands."}
    for name in ("system_check", "camera_detection", "serial_ports", "last_snapshot_report", "cameras"):
        path = LOCAL / f"{name}.json"
        if path.exists():
            report[name] = json.loads(path.read_text(encoding="utf-8"))
    target = LOCAL / f"diagnostics_{datetime.now():%Y%m%d_%H%M%S}_{uuid4().hex[:6]}.json"
    write_json(target, report)
    print("Saved:", target)
    print("Review this file before sharing. Nothing has been uploaded.")
    return target


def menu():
    while True:
        print("\nWINDOWS CAMERA & CALIBRATION FILE TOOLKIT")
        print("1  System/dependency check\n2  List Windows serial ports (OS metadata only)")
        print("3  Detect cameras\n4  Preview one or more cameras\n5  Save camera snapshots")
        print("6  Save a camera label\n7  Check / back up a calibration JSON")
        print("8  Export local diagnostics\n9  Change camera backend\n0  Exit")
        try:
            choice = input("Choose: ").strip()
            if choice == "0":
                return
            if choice == "1":
                doctor()
            elif choice == "2":
                show_ports()
            elif choice == "3":
                detect(selected_backend())
            elif choice in ("4", "5"):
                indices = ask_indices()
                if indices:
                    function = preview if choice == "4" else snapshots
                    function(indices, selected_backend(), 640, 480, 30)
            elif choice == "6":
                label_cameras()
            elif choice == "7":
                calibration_menu()
            elif choice == "8":
                export_report()
            elif choice == "9":
                config = settings()
                value = input(f"Backend ({'/'.join(BACKENDS)}), current={config['backend']}: ").strip()
                if value not in BACKENDS:
                    raise ValueError("Unknown backend")
                if value != config["backend"]:
                    config = {"backend": value, "cameras": {}}
                    write_json(LOCAL / "cameras.json", config)
                    print("Backend changed. Old index labels were cleared; detect and identify cameras again.")
            else:
                print("Choose a menu item from 0 to 9.")
        except (ValueError, OSError, ImportError, subprocess.SubprocessError) as exc:
            print("ERROR:", exc)
        except (KeyboardInterrupt, EOFError):
            print("\nReturning from toolkit.")
            return


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command")
    for name in ("doctor", "ports", "calibration-menu", "report"):
        commands.add_parser(name)
    d = commands.add_parser("detect")
    d.add_argument("--max-index", type=int, default=9, choices=range(32))
    d.add_argument("--backend", choices=BACKENDS)
    for name in ("preview", "snapshot"):
        p = commands.add_parser(name)
        p.add_argument("--indices", nargs="+", type=int, required=True)
        p.add_argument("--backend", choices=BACKENDS)
        p.add_argument("--width", type=int, default=640)
        p.add_argument("--height", type=int, default=480)
        p.add_argument("--fps", type=int, default=30)
    c = commands.add_parser("calibration-check")
    c.add_argument("path", type=Path)
    b = commands.add_parser("calibration-backup")
    b.add_argument("path", type=Path)
    b.add_argument("--role", required=True, choices=("leader", "follower"))
    args = parser.parse_args(argv)
    if args.command is None:
        menu()
        return 0
    if args.command == "doctor":
        return 0 if doctor() else 1
    if args.command == "ports":
        show_ports()
    elif args.command == "detect":
        return 0 if detect(selected_backend(args.backend), args.max_index) else 1
    elif args.command in ("preview", "snapshot"):
        if not (1 <= args.width <= 7680 and 1 <= args.height <= 4320 and 1 <= args.fps <= 120):
            raise ValueError("Invalid resolution or frame rate")
        function = preview if args.command == "preview" else snapshots
        return 0 if function(args.indices, selected_backend(args.backend), args.width, args.height, args.fps) else 1
    elif args.command == "calibration-menu":
        return 0 if calibration_menu() else 1
    elif args.command == "calibration-check":
        result = inspect_file(args.path)
        print(json.dumps(result, indent=2))
        return 0 if result["valid"] else 1
    elif args.command == "calibration-backup":
        path, result = backup_file(args.path, args.role, LOCAL / "calibration_backups")
        print("Saved:", path)
        print(json.dumps(result, indent=2))
    elif args.command == "report":
        export_report()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ValueError, OSError, ImportError, subprocess.SubprocessError) as exc:
        print("ERROR:", exc, file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(130)

