"""Install this toolkit's camera/file utilities into a private virtual environment."""

import argparse
import os
import platform
import struct
import subprocess
import sys
import venv
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run_logged(command, log):
    print("Running:", subprocess.list2cmdline(command), flush=True)
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, encoding="utf-8", errors="replace", cwd=ROOT)
    for line in process.stdout:
        print(line, end="", flush=True)
        log.write(line)
        log.flush()
    if process.wait() != 0:
        raise RuntimeError(f"Command failed with exit code {process.returncode}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--allow-non-windows", action="store_true", help="Development/CI only")
    args = parser.parse_args()
    if os.name != "nt" and not args.allow_non_windows:
        raise RuntimeError("This installer targets Windows 10/11. Use the Windows laptop.")
    if sys.version_info[:2] != (3, 12) or struct.calcsize("P") != 8:
        raise RuntimeError("Run with 64-bit Python 3.12.")
    if os.name == "nt" and platform.machine().lower() not in ("amd64", "x86_64"):
        raise RuntimeError("The pinned Windows wheels require x64 Python, not native ARM Python.")
    env_dir = ROOT / ".venv"
    python = env_dir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    (ROOT / "local").mkdir(exist_ok=True)
    with (ROOT / "local/setup.log").open("w", encoding="utf-8") as log:
        if env_dir.exists():
            if not python.exists():
                raise RuntimeError("Existing .venv is incomplete or from another OS. Rename it and retry.")
            check = subprocess.run([str(python), "-c", "import sys,struct; assert sys.version_info[:2]==(3,12) and struct.calcsize('P')==8"],
                                   capture_output=True, text=True)
            if check.returncode:
                raise RuntimeError("Existing .venv is incompatible. Rename it and rerun setup.")
        else:
            print("Creating .venv ...", flush=True)
            venv.EnvBuilder(with_pip=True).create(env_dir)
        run_logged([str(python), "-m", "pip", "install", "--upgrade", "pip"], log)
        run_logged([str(python), "-m", "pip", "install", "--only-binary=:all:", "-r", str(ROOT / "requirements.txt")], log)
        run_logged([str(python), "-m", "pip", "check"], log)
        run_logged([str(python), str(ROOT / "kit.py"), "doctor"], log)
    print("Ready. No camera was opened and no serial port was opened during setup.")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print(f"SETUP ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
