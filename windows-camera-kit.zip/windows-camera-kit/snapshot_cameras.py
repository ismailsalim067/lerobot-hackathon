"""Compatibility entry point: pass explicitly verified camera indices."""
import sys
from kit import ask_indices, main

if __name__ == "__main__":
    indices = [int(value) for value in sys.argv[1:]] if len(sys.argv) > 1 else ask_indices()
    sys.exit(main(["snapshot", "--indices", *map(str, indices)]) if indices else 0)
