import copy
import hashlib
import json
import subprocess
import tempfile
import unittest
from itertools import count
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import cv2
import numpy as np

import calibration_files as calibration
import camera_worker
import kit


def sample_calibration():
    return {name: {"id": motor_id, "drive_mode": 0, "homing_offset": -100,
                   "range_min": 0 if name == "wrist_roll" else 900,
                   "range_max": 4095 if name == "wrist_roll" else 3100}
            for name, motor_id in calibration.JOINTS.items()}


class CalibrationTests(unittest.TestCase):
    def test_valid_complete_file(self):
        self.assertTrue(calibration.validate(sample_calibration())["valid"])

    def test_missing_joint(self):
        data = sample_calibration()
        del data["gripper"]
        self.assertFalse(calibration.validate(data)["valid"])

    def test_unexpected_joint(self):
        data = sample_calibration()
        data["extra"] = data["gripper"]
        self.assertFalse(calibration.validate(data)["valid"])

    def test_wrong_motor_id(self):
        data = sample_calibration()
        data["gripper"]["id"] = 1
        self.assertFalse(calibration.validate(data)["valid"])

    def test_booleans_and_floats_rejected(self):
        for value in (True, 1.0, "1", None):
            data = sample_calibration()
            data["shoulder_pan"]["id"] = value
            self.assertFalse(calibration.validate(data)["valid"])

    def test_invalid_roots_and_joint_shape(self):
        for data in ([], None, "text", 3):
            self.assertFalse(calibration.validate(data)["valid"])
        data = sample_calibration()
        data["gripper"] = []
        self.assertFalse(calibration.validate(data)["valid"])

    def test_invalid_ranges_and_offsets(self):
        for values in ({"range_min": 1000, "range_max": 1000}, {"range_min": -1},
                       {"range_max": 4096}, {"homing_offset": 2048}, {"drive_mode": 2}):
            data = sample_calibration()
            data["gripper"].update(values)
            self.assertFalse(calibration.validate(data)["valid"])

    def test_small_range_warns_without_claiming_physical_validity(self):
        data = sample_calibration()
        data["gripper"]["range_max"] = 905
        result = calibration.validate(data)
        self.assertTrue(result["valid"])
        self.assertTrue(result["warnings"])
        self.assertIn("no physical calibration", result["scope"])

    def test_backup_preserves_bytes_and_never_overwrites(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "calibration with spaces 校准.json"
            raw = b"\xef\xbb\xbf" + json.dumps(sample_calibration(), indent=3).encode()
            source.write_bytes(raw)
            a, report = calibration.backup_file(source, "leader", root / "backups")
            b, _ = calibration.backup_file(source, "leader", root / "backups")
            self.assertNotEqual(a, b)
            self.assertEqual(a.read_bytes(), raw)
            self.assertEqual(source.read_bytes(), raw)
            self.assertEqual(report["sha256"], hashlib.sha256(raw).hexdigest())
            self.assertFalse(report["applied_to_hardware"])

    def test_invalid_file_is_not_backed_up(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "bad.json"
            source.write_text("{}")
            with self.assertRaises(ValueError):
                calibration.backup_file(source, "follower", root / "backup")
            self.assertFalse((root / "backup").exists())

    def test_invalid_role(self):
        with self.assertRaises(ValueError):
            calibration.backup_file("unused.json", "wrong", "unused")


class FakeCamera:
    def __init__(self, opened=True, frames=True):
        self.opened, self.frames, self.released = opened, frames, False

    def isOpened(self):
        return self.opened

    def read(self):
        return (True, np.zeros((480, 640, 3), dtype=np.uint8)) if self.frames else (False, None)

    def get(self, _):
        return 30.0

    def getBackendName(self):
        return "FAKE_BACKEND"

    def release(self):
        self.released = True


class CameraTests(unittest.TestCase):
    def args(self, output=""):
        return SimpleNamespace(indices=[2], backend="dshow", width=640, height=480, fps=30, output=output)

    def test_probe_requires_actual_frames(self):
        cap = FakeCamera(frames=False)
        with patch.object(camera_worker, "open_camera", return_value=cap), \
             patch.object(camera_worker.time, "monotonic", side_effect=count(0, 1)), \
             patch.object(camera_worker.time, "sleep"):
            result = camera_worker.probe(self.args(), cv2)
        self.assertTrue(result["opened"])
        self.assertFalse(result["frame_ok"])
        self.assertTrue(cap.released)

    def test_probe_closed_device_released(self):
        cap = FakeCamera(opened=False)
        with patch.object(camera_worker, "open_camera", return_value=cap):
            result = camera_worker.probe(self.args(), cv2)
        self.assertFalse(result["frame_ok"])
        self.assertTrue(cap.released)

    def test_probe_returns_frame_size_without_saving(self):
        cap = FakeCamera()
        with patch.object(camera_worker, "open_camera", return_value=cap), \
             patch.object(camera_worker.time, "monotonic", side_effect=count(0, 0.2)), \
             patch.object(camera_worker.time, "sleep"):
            result = camera_worker.probe(self.args(), cv2)
        self.assertTrue(result["frame_ok"])
        self.assertEqual((result["width"], result["height"]), (640, 480))
        self.assertNotIn("saved", result)
        self.assertTrue(cap.released)

    def test_worker_exception_releases_device(self):
        cap = FakeCamera()
        cap.read = lambda: (_ for _ in ()).throw(RuntimeError("camera unplugged"))
        with patch.object(camera_worker, "open_camera", return_value=cap):
            result = camera_worker.probe(self.args(), cv2)
        self.assertIn("unplugged", result["error"])
        self.assertTrue(cap.released)

    def test_snapshot_unicode_path_and_unique_names(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory) / "pictures with spaces 相机"
            frame = np.full((24, 32, 3), 100, dtype=np.uint8)
            a = Path(camera_worker.save_jpeg(cv2, frame, folder, 2))
            b = Path(camera_worker.save_jpeg(cv2, frame, folder, 2))
            self.assertNotEqual(a, b)
            decoded = cv2.imdecode(np.frombuffer(a.read_bytes(), np.uint8), cv2.IMREAD_COLOR)
            self.assertEqual(decoded.shape, frame.shape)

    def test_failed_encoding_does_not_write(self):
        fake_cv2 = SimpleNamespace(imencode=lambda *_: (False, None))
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(RuntimeError):
                camera_worker.save_jpeg(fake_cv2, None, directory, 0)
            self.assertEqual(list(Path(directory).iterdir()), [])

    def test_probe_timeout_is_reported(self):
        with patch.object(kit.subprocess, "run", side_effect=subprocess.TimeoutExpired("camera", 15)):
            result = kit.probe_camera(3, "dshow")
        self.assertFalse(result["frame_ok"])
        self.assertIn("stopped", result["error"])

    def test_bad_worker_output_is_not_success(self):
        process = SimpleNamespace(stdout="not json", stderr="driver failed", returncode=1)
        with patch.object(kit.subprocess, "run", return_value=process):
            result = kit.probe_camera(3, "dshow")
        self.assertFalse(result["frame_ok"])
        self.assertIn("driver failed", result["error"])

    def test_worker_json_result(self):
        process = SimpleNamespace(stdout='log line\n{"index": 3, "frame_ok": true}\n', stderr="", returncode=0)
        with patch.object(kit.subprocess, "run", return_value=process):
            self.assertTrue(kit.probe_camera(3, "dshow")["frame_ok"])

    def test_camera_indices_validated(self):
        for indices in ([], [-1], [32], [1, 1], [True]):
            with self.assertRaises(ValueError):
                kit.worker_command("probe", indices, "dshow")

    def test_commands_keep_paths_as_single_arguments(self):
        path = Path("C:/Users/Team Member/Pictures")
        command = kit.worker_command("probe", [1], "msmf", output=path)
        self.assertEqual(command[-1], str(path))
        self.assertNotIn("shell", command)


class StorageTests(unittest.TestCase):
    def test_atomic_json_and_defaults(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(kit, "LOCAL", Path(directory)):
            self.assertEqual(kit.settings()["cameras"], {})
            data = {"backend": "dshow", "cameras": {}}
            kit.write_json(Path(directory) / "cameras.json", data)
            self.assertEqual(kit.settings(), data)
            self.assertEqual(len(list(Path(directory).glob("*.tmp"))), 0)

    def test_invalid_settings_fail_clearly(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(kit, "LOCAL", Path(directory)):
            kit.write_json(Path(directory) / "cameras.json", {"backend": "invalid", "cameras": {}})
            with self.assertRaises(ValueError):
                kit.settings()


if __name__ == "__main__":
    unittest.main()
